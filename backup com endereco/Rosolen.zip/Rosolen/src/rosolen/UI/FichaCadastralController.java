/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.UI;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import java.io.IOException;
import java.net.URL;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javax.swing.JFrame;
import rosolen.db.controladoras.CtrCategoria;
import rosolen.db.controladoras.CtrEndereco;
import rosolen.db.controladoras.CtrPessoa;
import rosolen.db.controladoras.CtrSituacao;
import rosolen.db.entidades.Endereco;
import rosolen.db.entidades.Pessoa;
import rosolen.db.entidades.Situacao;
import rosolen.db.entidades.Usuario;
import rosolen.db.util.Conexao;
import rosolen.db.util.MaskFieldUtil;

/**
 * FXML Controller class
 *
 * @author thale
 */
public class FichaCadastralController implements Initializable
{

    public static final String FXML = "FichaCadastral.fxml";

    @FXML
    private HBox hb_botoes;
    @FXML
    private Button bt_novo;
    @FXML
    private Button bt_alterar;
    @FXML
    private Button bt_apagar;
    @FXML
    private Button bt_confirmar;
    @FXML
    private Button bt_cancelar;
    @FXML
    private AnchorPane pn_dados;
    @FXML
    private TextField txt_codigo;
    @FXML
    private TextField txt_nome;
    @FXML
    private TextField txt_cpf;
    @FXML
    private TextField txt_telefone;
    @FXML
    private TextField txt_email;
    @FXML
    private TextField txt_cep;
    @FXML
    private TextField txt_tipologradouro;
    @FXML
    private TextField txt_logradouro;
    @FXML
    private TextField txt_cidade;
    @FXML
    private TextField txt_uf;
    @FXML
    private TextField txt_bairro;
    @FXML
    private TextField txt_numero;
    @FXML
    private ImageView foto;
    @FXML
    private BorderPane pn_procura;
    @FXML
    private TableView<Pessoa> tabela;
    @FXML
    private TableColumn<?, ?> col_cod;
    @FXML
    private TableColumn<?, ?> col_nome;
    @FXML
    private TableColumn<?, ?> col_cpf;
    @FXML
    private TableColumn<?, ?> col_telefone;
    @FXML
    private TableColumn<?, ?> col_cep;
    @FXML
    private TableColumn<?, ?> col_email;
    @FXML
    private HBox hb_procurar;
    @FXML
    private TextField txt_procurar;
    @FXML
    private Button bt_procurar;
    @FXML
    private ToggleGroup Sexo;
    @FXML
    private RadioButton rb_homem;
    @FXML
    private RadioButton rb_mulher;
    @FXML
    private Label lb_resultado;
    @FXML
    private VBox pn_fichacadastral;
    @FXML
    private DatePicker dp_datacadastro;
    @FXML
    private ComboBox<Situacao> cb_situacao;
    @FXML
    private DatePicker dp_datanascimento;

    private int status;
    Webcam webcam;
    JFrame window;
    Endereco end;
    @FXML
    private TextField txt_credito;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        // TODO
        col_cod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        col_nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        col_cpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
        col_telefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        col_email.setCellValueFactory(new PropertyValueFactory<>("email"));
        col_cep.setCellValueFactory(new PropertyValueFactory<>("endereco"));

        MaskFieldUtil.cpfField(this.txt_cpf);
        MaskFieldUtil.onlyAlfaNumericValue(this.txt_nome);
        MaskFieldUtil.foneField(this.txt_telefone);
        MaskFieldUtil.monetaryField(txt_credito);

        Sexo.getToggles().get(0).setUserData("H");
        Sexo.getToggles().get(1).setUserData("M");

        CtrSituacao ctrsit = new CtrSituacao();
        for (Situacao s : ctrsit.getAll())
            cb_situacao.getItems().add(s);

        webcam = Webcam.getDefault();
        webcam.setViewSize(WebcamResolution.VGA.getSize());
        limpaTela();
    }

    public Usuario getInfoTela()
    {
        Usuario u;
        try
        {
            u = new Usuario(status == 1 ? 0 : Integer.parseInt(txt_codigo.getText()), txt_nome.getText(), txt_cpf.getText().replaceAll("[^A-Za-z0-9]", ""),
                    txt_telefone.getText().replaceAll("[^A-Za-z0-9 ]", ""), txt_email.getText(), end, txt_numero.getText().trim().isEmpty() ? 0 : Integer.parseInt(txt_numero.getText()),
                    foto.getImage() != null ? SwingFXUtils.fromFXImage(foto.getImage(), null) : null, ((String) Sexo.getSelectedToggle().getUserData()).charAt(0),
                    cb_situacao.getValue(),
                    new Timestamp(Date.from(dp_datacadastro.getValue().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()).getTime()),
                    new Timestamp(Date.from(dp_datanascimento.getValue().atStartOfDay().atZone(ZoneId.systemDefault()).toInstant()).getTime()),
                    Float.parseFloat(txt_credito.getText().replace(",", ".")), 0,
                    "", new CtrCategoria().get(3));

        } catch (NumberFormatException ex)
        {
            System.out.println(ex.getMessage());
            u = null;
        }
        return u;
    }

    public void limpaTela()
    {
        txt_codigo.setDisable(true);
        bt_confirmar.setDisable(true);
        bt_cancelar.setDisable(true);
        bt_novo.setDisable(false);
        bt_alterar.setDisable(false);
        bt_apagar.setDisable(false);
        pn_dados.setDisable(true);
        hb_procurar.setDisable(false);
        pn_procura.setDisable(true);
        txt_tipologradouro.setDisable(true);
        txt_logradouro.setDisable(true);
        txt_cidade.setDisable(true);
        txt_uf.setDisable(true);
        txt_bairro.setDisable(true);
        rb_homem.setSelected(true);
        tabela.setDisable(true);
        txt_credito.setDisable(true);

        txt_codigo.setText("");
        txt_nome.setText("");
        txt_cpf.setText("");
        txt_telefone.setText("");
        txt_email.setText("");
        txt_cep.setText("");
        txt_tipologradouro.setText("");
        txt_logradouro.setText("");
        txt_cidade.setText("");
        txt_uf.setText("");
        txt_bairro.setText("");
        txt_numero.setText("");
        txt_procurar.setText("");
        lb_resultado.setText("");
        txt_credito.setText("0");

        tabela.setItems(null);
        foto.setImage(null);
        
        end = null;

        cb_situacao.getSelectionModel().select(0);
        dp_datacadastro.setValue(LocalDate.now());
        dp_datanascimento.setValue(LocalDate.now());
        Platform.runLater(()
                ->
        {
            lb_resultado.setText("");
        });
    }

    public void setInfoTela(Pessoa p)
    {
        if (p != null)
        {
            txt_tipologradouro.setDisable(true);
            txt_logradouro.setDisable(true);
            txt_cidade.setDisable(true);
            txt_uf.setDisable(true);
            txt_bairro.setDisable(true);

            txt_codigo.setText(String.valueOf(p.getCod()));
            txt_nome.setText(p.getNome());
            txt_cpf.setText(p.getCpf());
            txt_telefone.setText(p.getTelefone());
            txt_email.setText(p.getEmail());
            txt_cep.setText(p.getEndereco().getCep());
            txt_tipologradouro.setText(p.getEndereco().getTipolog());
            txt_logradouro.setText(p.getEndereco().getLogradouro());
            txt_cidade.setText(p.getEndereco().getCidade().getNome());
            txt_uf.setText(p.getEndereco().getCidade().getEstado().getSigla());
            txt_bairro.setText(p.getEndereco().getBairro());
            txt_numero.setText("" + p.getNumero());
            foto.setImage(p.getImg() != null ? SwingFXUtils.toFXImage(p.getImg(), null) : null);
            if (p.getSexo() == 'H')
                rb_homem.setSelected(true);
            else if (p.getSexo() == 'M')
                rb_mulher.setSelected(true);
            cb_situacao.getSelectionModel().select(p.getSituacao());
            dp_datacadastro.setValue(p.getDatacadastro().toLocalDateTime().toLocalDate());
            dp_datanascimento.setValue(p.getDatanascimento().toLocalDateTime().toLocalDate());
        }
    }

    @FXML
    private void evt_novo(ActionEvent event)
    {
        txt_codigo.setDisable(true);
        pn_dados.setDisable(false);
        hb_procurar.setDisable(true);
        tabela.setDisable(true);
        bt_novo.setDisable(true);
        bt_alterar.setDisable(true);
        bt_apagar.setDisable(true);
        bt_confirmar.setDisable(false);
        bt_cancelar.setDisable(false);
        txt_credito.setDisable(false);
        status = 1;
    }

    @FXML
    private void evt_alterar(ActionEvent event)
    {
        bt_novo.setDisable(true);
        bt_alterar.setDisable(true);
        bt_apagar.setDisable(true);
        bt_confirmar.setDisable(false);
        bt_cancelar.setDisable(false);
        pn_dados.setDisable(true);
        pn_procura.setDisable(false);
        tabela.setDisable(false);
        status = 2;
    }

    @FXML
    private void evt_apagar(ActionEvent event)
    {
        bt_novo.setDisable(true);
        bt_alterar.setDisable(true);
        bt_apagar.setDisable(true);
        bt_confirmar.setDisable(false);
        bt_cancelar.setDisable(false);
        pn_dados.setDisable(true);
        pn_procura.setDisable(false);
        tabela.setDisable(false);
        status = 3;
    }

    @FXML
    private void evt_confirmar(ActionEvent event)
    {

        boolean valida = true;

        Alert alerta = new Alert(Alert.AlertType.WARNING);
        alerta.setTitle("Informações não preenchidas!");

        if (txt_nome.getText().trim().isEmpty())
        {
            valida = false;
            alerta.setHeaderText("Erro no NOME!");
            alerta.setContentText("O Nome precisa estar preenchido!");
            alerta.showAndWait();
            txt_nome.requestFocus();
        }

        if (valida)
        {
            if (end == null)
                end = new Endereco();
            else
            {
                CtrEndereco ctrend = new CtrEndereco();
                if (ctrend.get(end.getCep()) == null)
                    valida = ctrend.salvar(end);
            }

            if (valida)
            {
                CtrPessoa ctr = new CtrPessoa();
                switch (status)
                {
                    case 1:
                        valida = ctr.salvar(getInfoTela());
                        break;
                    case 2:
                        valida = ctr.alterar(getInfoTela());
                        break;
                    case 3:
                        valida = ctr.apagar(getInfoTela());
                        break;
                }
            }

            if (valida)
                limpaTela();
            else
            {
                alerta.alertTypeProperty().set(Alert.AlertType.ERROR);
                alerta.setTitle("Erro na Gravação");
                alerta.setHeaderText("Houve um erro ao registrar no sistema!\nContate o suporte técnico.");
                alerta.setContentText(Conexao.get().getMensagemErro());
                alerta.showAndWait();
            }
        }
    }

    @FXML
    private void evt_cancelar(ActionEvent event)
    {
        limpaTela();
    }

    @FXML
    private void evt_procurar(ActionEvent event)
    {

        String filtro = "";
        if (!txt_procurar.getText().trim().isEmpty())
            filtro = "nome ilike '%" + txt_procurar.getText() + "%'";
        ObservableList<Pessoa> ob = FXCollections.observableArrayList(new CtrPessoa().get(new Usuario(), filtro, "order by nome limit 20"));
        if (ob.size() > 0)
            tabela.setItems(ob);
        else
            tabela.setItems(null);
    }

    @FXML
    private void evt_ligar(ActionEvent event)
    {

        WebcamPanel panel = new WebcamPanel(webcam);
        window = new JFrame("WEBCAM");
        window.add(panel);
        window.setResizable(true);
        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        window.setVisible(true);
        window.setAlwaysOnTop(true);
        window.pack();
        window.requestFocus();
    }

    @FXML
    private void evt_capturar(ActionEvent event) throws IOException
    {
        if (window != null)
        {
            foto.setImage(SwingFXUtils.toFXImage(webcam.getImage(), null));
            window.dispose();
            webcam.close();
            window = null;
        }
    }

    @FXML
    private void evt_selecionar(MouseEvent event)
    {
        txt_codigo.setText("");
        txt_nome.setText("");
        txt_cpf.setText("");
        txt_telefone.setText("");
        txt_email.setText("");
        txt_cep.setText("");
        txt_tipologradouro.setText("");
        txt_logradouro.setText("");
        txt_cidade.setText("");
        txt_uf.setText("");
        txt_bairro.setText("");
        txt_numero.setText("");
        txt_procurar.setText("");
        lb_resultado.setText("");
        txt_credito.setText("0");
        cb_situacao.getSelectionModel().selectFirst();
        dp_datanascimento.setValue(LocalDate.of(1900, 1, 1));
        dp_datacadastro.setValue(LocalDate.of(1900, 1, 1));
        foto.setImage(null);        
        end = null;
        
        Usuario u = (Usuario) tabela.getSelectionModel().getSelectedItem();
        if (u != null)
        {
            pn_dados.setDisable(false);
            setInfoTela(u);
            end = u.getEndereco();
        }
    }

}
