/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.UI;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import rosolen.db.controladoras.CtrLancamento;
import rosolen.db.controladoras.CtrPessoa;
import rosolen.db.controladoras.CtrServico;
import rosolen.db.entidades.Lancamento;
import rosolen.db.entidades.Pessoa;
import rosolen.db.entidades.Servico;
import rosolen.db.entidades.Usuario;
import rosolen.db.util.Conexao;
import rosolen.db.util.MaskFieldUtil;

/**
 * FXML Controller class
 *
 * @author thales
 */
public class LancamentosController implements Initializable
{

    //region Variaveis
    public static final String FXML = "Lancamentos.fxml";
    private float total;
    private float desconto;
    private float credito;
    private float avaliacao;
    private float mensalidade;
    private Pessoa cliente;
    private static final DecimalFormat df = new DecimalFormat("###.##");
    @FXML
    private TextField txt_pagamento;
    @FXML
    private CheckBox chk_avaliacao;
    @FXML
    private RadioButton rb_mensalidadeNormal;
    @FXML
    private RadioButton rb_creditoNao;
    @FXML
    private RadioButton rb_creditoSim;
    @FXML
    private RadioButton rb_descontoReais;
    @FXML
    private RadioButton rb_descontoPorcentagem;
    @FXML
    private RadioButton rb_notaSim;
    @FXML
    private RadioButton rb_notaNao;
    @FXML
    private Label lb_total;
    @FXML
    private Label lb_troco;
    @FXML
    private BorderPane pn_procura;
    @FXML
    private HBox hb_procurar;
    @FXML
    private TextField txt_cod;
    @FXML
    private TextField txt_nome;
    @FXML
    private TextField txt_CPF;
    @FXML
    private TextField txt_telefone;
    @FXML
    private TextField txt_email;
    @FXML
    private ImageView fotoPessoa;
    @FXML
    private TableView<Pessoa> tabelaPessoa;
    @FXML
    private TableColumn<?, ?> col_cod;
    @FXML
    private TableColumn<?, ?> col_nome;
    @FXML
    private TableColumn<?, ?> col_cpf;
    @FXML
    private TableColumn<?, ?> col_telefone;
    @FXML
    private TableColumn<?, ?> col_email;
    @FXML
    private TextField txt_procurarPessoa;
    @FXML
    private CheckBox chk_mensalidade;
    @FXML
    private TextField txt_credito;
    @FXML
    private CheckBox chk_desconto;
    @FXML
    private TextField txt_desconto;
    @FXML
    private RadioButton rb_trococreditoNao;
    @FXML
    private RadioButton rb_trococreditoSim;
    @FXML
    private ToggleGroup grupoMensalidade;
    @FXML
    private ToggleGroup grupoDesconto;
    @FXML
    private ToggleGroup grupoCpfNota;
    @FXML
    private ToggleGroup grupoCredito;
    @FXML
    private ToggleGroup grupoTrocoCredito;
    @FXML
    private AnchorPane pn_dados1;
    @FXML
    private Label lb_desconto;
    @FXML
    private RadioButton rb_mensalidadeFamiliar;
    @FXML
    private DatePicker dp_UltimaMens;
    @FXML
    private DatePicker dp_MensalidadePagar;
    @FXML
    private TextField txt_situacao;
    @FXML
    private ToggleGroup grupoCombo;
    @FXML
    private RadioButton rb_mensalidade3;
    @FXML
    private RadioButton rb_mensalidade6;
    @FXML
    private RadioButton rb_mensalidadeAnual;
    @FXML
    private RadioButton rb_mensalidadeUnica;
    @FXML
    private Button btn_registrarlancamento;

    //endregion
    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        // TODO
        desconto = 0f;
        total = 0f;
        MaskFieldUtil.cpfField(txt_CPF);
        MaskFieldUtil.foneField(txt_telefone);
        MaskFieldUtil.onlyAlfaNumericValue(txt_procurarPessoa);
        MaskFieldUtil.onlyDigitsValue(txt_desconto);
        MaskFieldUtil.onlyDigitsValue(txt_pagamento);

        //Pessoa
        col_cod.setCellValueFactory(new PropertyValueFactory<>("cod"));
        col_nome.setCellValueFactory(new PropertyValueFactory<>("nome"));
        col_cpf.setCellValueFactory(new PropertyValueFactory<>("cpf"));
        col_telefone.setCellValueFactory(new PropertyValueFactory<>("telefone"));
        col_email.setCellValueFactory(new PropertyValueFactory<>("email"));

        chk_avaliacao.selectedProperty().addListener((observable) ->
        {
            validarDados();
        });

        chk_mensalidade.selectedProperty().addListener((observable, oldValue, newValue) ->
        {
            grupoMensalidade.getToggles().forEach((t) ->
            {
                ((Node) t).setDisable(!newValue);
            });
            grupoCombo.getToggles().forEach((t) ->
            {
                ((Node) t).setDisable(!newValue);
            });
            dp_MensalidadePagar.setDisable(!newValue);
            validarDados();
        });

        grupoMensalidade.selectedToggleProperty().addListener((observable) ->
        {
            validarDados();
        });

        grupoCombo.selectedToggleProperty().addListener((observable) ->
        {
            validarDados();
        });

        chk_desconto.selectedProperty().addListener((observable, oldValue, newValue) ->
        {
            grupoDesconto.getToggles().forEach((t) ->
            {
                ((Node) t).setDisable(!newValue);
            });
            txt_desconto.setDisable(!newValue);
            validarDados();
        });

        grupoDesconto.selectedToggleProperty().addListener((observable) ->
        {
            txt_desconto.setText("0");
            validarDados();
        });

        txt_desconto.focusedProperty().addListener((observable, oldValue, newValue) ->
        {
            if (!newValue)
                validarDados();
        });

        grupoCredito.selectedToggleProperty().addListener((observable) ->
        {
            validarDados();
        });

        txt_pagamento.focusedProperty().addListener((observable, oldValue, newValue) ->
        {
            if (!newValue)
                validarDados();
        });

        txt_desconto.setOnKeyPressed((KeyEvent ke) ->
        {
            if (ke.getCode().equals(KeyCode.ENTER))
                validarDados();
        });

        txt_pagamento.setOnKeyPressed((KeyEvent ke) ->
        {
            if (ke.getCode().equals(KeyCode.ENTER))
                validarDados();

        });

        limpaTela();
        validarDados();
    }

    private void limpaTela()
    {
        txt_cod.setText("");
        txt_nome.setText("");
        txt_CPF.setText("");
        txt_telefone.setText("");
        txt_email.setText("");
        txt_credito.setText("0");
        txt_procurarPessoa.setText("");
        txt_desconto.setText("0");
        txt_pagamento.setText("0");
        txt_situacao.setText("");

        fotoPessoa.setImage(null);

        tabelaPessoa.getItems().clear();

        chk_avaliacao.setSelected(false);
        chk_mensalidade.setSelected(false);
        rb_mensalidadeNormal.setSelected(true);
        rb_mensalidadeUnica.setSelected(true);
        dp_MensalidadePagar.setDisable(true);
        chk_desconto.setSelected(false);
        rb_descontoReais.setSelected(true);
        rb_creditoNao.setSelected(true);
        rb_notaSim.setSelected(true);
        rb_trococreditoNao.setSelected(true);
        btn_registrarlancamento.setDisable(true);

        pn_dados1.setDisable(true);

        Platform.runLater(() ->
        {
            lb_desconto.setText("");
            lb_total.setText("0.00");
            lb_troco.setText("0.00");
        });
    }

    private void validarDados()
    {
        total = 0f;
        desconto = 0f;
        avaliacao = 0f;
        mensalidade = 0f;
        credito = 0f;

        if (cliente != null)
        {
            if (chk_avaliacao.isSelected())
                total += avaliacao = new CtrServico().get(3).getValor();

            if (chk_mensalidade.isSelected())
            {
                Servico serSelecionado;
                if (rb_mensalidadeNormal.isSelected())
                    serSelecionado = new CtrServico().get(1);
                else
                    serSelecionado = new CtrServico().get(2);

                mensalidade = serSelecionado.getValor();

                if (rb_mensalidadeUnica.isSelected())
                    total += serSelecionado.getValor();
                else if (rb_mensalidade3.isSelected())
                    total += serSelecionado.getValor() * 3f;
                else if (rb_mensalidade6.isSelected())
                    total += serSelecionado.getValor() * 6f;
                else if (rb_mensalidadeAnual.isSelected())
                    total += serSelecionado.getValor() * 12f;
            }

            if (chk_desconto.isSelected())
            {
                float valor = 0f;
                if (txt_desconto.getText().trim().isEmpty())
                    txt_desconto.setText("0.0");
                else
                {
                    valor = Float.parseFloat(txt_desconto.getText().replace(",", "."));
                    if (valor < 0)
                    {
                        valor *= -1f;
                        txt_desconto.setText(String.valueOf(valor));
                    }
                }

                if (valor > 0f)
                {
                    if (rb_descontoReais.isSelected())
                    {
                        if (valor > total)
                            valor = total;

                        desconto = valor / total;
                    } else
                    {
                        if (valor > 100)
                            valor = 100f;

                        desconto = valor / 100f;
                    }
                    txt_desconto.setText(String.valueOf(valor));
                }
            }

            if (rb_creditoSim.isSelected())
                credito = cliente.getCredito();

            float valor = 0f;
            if (txt_pagamento.getText().trim().isEmpty())
                txt_pagamento.setText("0.0");
            else
            {
                valor = Float.parseFloat(txt_pagamento.getText().replace(",", "."));
                if (valor < 0)
                    valor *= -1f;
                txt_pagamento.setText(String.valueOf(valor));
            }

            float aux = (total - credito - (total * desconto));
            boolean desabilitar = true;
            if (chk_avaliacao.isSelected() || chk_mensalidade.isSelected())
                if (valor - aux >= 0)
                    desabilitar = false;
            btn_registrarlancamento.setDisable(desabilitar);

            String stotal = String.valueOf(df.format(aux));
            String stroco = String.valueOf(valor - aux >= 0f ? df.format(valor - aux) : 0f);

            Platform.runLater(() ->
            {
                if (desconto > 0)
                    lb_desconto.setText("-" + df.format(total * desconto) + "R$");
                else
                    lb_desconto.setText("");
                lb_total.setText(stotal);
                lb_troco.setText(stroco);
            });
        }
    }

    @FXML
    private void evt_procurarPessoa(ActionEvent event)
    {
        String filtro = "";
        if (!txt_procurarPessoa.getText().trim().isEmpty())
            filtro = "lower(nome) like '%" + txt_procurarPessoa.getText() + "%'";
        ObservableList<Pessoa> ob = FXCollections.observableArrayList(new CtrPessoa().get(new Usuario(), filtro, "order by nome limit 20"));
        if (ob.size() > 0)
            tabelaPessoa.setItems(ob);
        else
            tabelaPessoa.setItems(null);
    }

    @FXML
    private void evt_selecionarPessoa(MouseEvent event)
    {
        cliente = tabelaPessoa.getSelectionModel().getSelectedItem();
        if (cliente != null)
        {
            txt_cod.setText("" + cliente.getCod());
            txt_nome.setText(cliente.getNome());
            txt_CPF.setText(cliente.getCpf());
            txt_telefone.setText(cliente.getTelefone());
            txt_email.setText(cliente.getEmail());
            txt_situacao.setText(cliente.getSituacao().getDescricao().toUpperCase());

            switch (cliente.getSituacao().getCod())
            {
                case 1:
                    txt_situacao.setStyle("-fx-text-fill: green;");
                    break;

                case 2:
                    txt_situacao.setStyle("-fx-text-fill: red;");
                    break;

                case 3:
                    txt_situacao.setStyle("-fx-text-fill: black;");
                    break;

                case 4:
                    txt_situacao.setStyle("-fx-text-fill: orange;");
                    break;

                default:
                    txt_situacao.setStyle("-fx-text-fill: black;");
                    break;
            }

            dp_UltimaMens.setValue(new CtrLancamento().ultimaMensalidade(cliente.getCod()));
            if (dp_UltimaMens.getValue().getYear() != 1900)
                dp_MensalidadePagar.setValue(dp_UltimaMens.getValue().plusMonths(1));
            else
                dp_MensalidadePagar.setValue(LocalDate.now());
            txt_credito.setText("" + cliente.getCredito());
            fotoPessoa.setImage(cliente.getImg() != null ? SwingFXUtils.toFXImage(cliente.getImg(), null) : null);
            pn_dados1.setDisable(false);
        }
    }

    @FXML
    private void evt_registrarLancamento(ActionEvent event)
    {
        boolean valido = false;
        LocalDate ldultima = dp_UltimaMens.getValue();
        LocalDate ldpagar = dp_MensalidadePagar.getValue();

        if (ldultima.getYear() != 1900)
            if (ldultima.getYear() < ldpagar.getYear())
                if (ldultima.getYear() + 1 == ldpagar.getYear() && ldultima.plusMonths(1).getMonthValue() == ldpagar.getMonthValue())
                    valido = true;
                else
                {
                    Alert al = new Alert(Alert.AlertType.CONFIRMATION);
                    al.setContentText("Há mensalidades a ser pagas ainda, deseja realmente anulá-las?");
                    al.getButtonTypes().clear();
                    al.getButtonTypes().add(new ButtonType("Sim", ButtonBar.ButtonData.YES));
                    al.getButtonTypes().add(new ButtonType("Nao", ButtonBar.ButtonData.NO));
                    al.showAndWait();
                    if (al.getResult().getButtonData() == ButtonBar.ButtonData.YES)
                        valido = true;
                }
            else if (ldultima.getYear() == ldpagar.getYear())
                if (ldultima.getMonthValue() == ldpagar.getMonthValue())
                    new Alert(Alert.AlertType.ERROR, "Essa mensalidade já foi paga!", ButtonType.OK).showAndWait();
                else if (ldultima.getMonthValue() + 1 == ldpagar.getMonthValue())
                    valido = true;
                else
                {
                    Alert al = new Alert(Alert.AlertType.CONFIRMATION);
                    al.setContentText("Há mensalidades a ser pagas ainda, deseja realmente anulá-las?");
                    al.getButtonTypes().clear();
                    al.getButtonTypes().add(new ButtonType("Sim", ButtonBar.ButtonData.YES));
                    al.getButtonTypes().add(new ButtonType("Nao", ButtonBar.ButtonData.NO));
                    al.showAndWait();
                    if (al.getResult().getButtonData() == ButtonBar.ButtonData.YES)
                        valido = true;
                }
            else
                new Alert(Alert.AlertType.ERROR, "Ano da mensalidade a pagar nao pode ser menor que o ano da ultima mensalidade paga!", ButtonType.OK).showAndWait();
        else
            valido = true;

        if (valido)
        {
            float parcelas = 0f;
            if (rb_mensalidadeNormal.isSelected() || rb_mensalidadeFamiliar.isSelected())
                parcelas = 1f;
            if (rb_mensalidade3.isSelected())
                parcelas = 3f;
            else if (rb_mensalidade6.isSelected())
                parcelas = 6f;
            else if (rb_mensalidadeAnual.isSelected())
                parcelas = 12f;

            ArrayList<Lancamento> all = new ArrayList();
            LocalDateTime dataPagamento = dp_MensalidadePagar.getValue().atStartOfDay();

            float valAval = avaliacao - (avaliacao * desconto);
            if (chk_avaliacao.isSelected())
            {
                Servico ser = new CtrServico().get(3);
                all.add(new Lancamento(cliente, rosolen.Rosolen.getInstance().getSessao(),
                        Timestamp.valueOf(dataPagamento), Timestamp.valueOf(LocalDateTime.now()), true, false, ser.getDescricao(), valAval));
            }

            float valParc = mensalidade - (mensalidade * desconto);
            if (chk_mensalidade.isSelected())
            {
                Lancamento lan;
                if (parcelas == 1)
                    all.add(new Lancamento(cliente, rosolen.Rosolen.getInstance().getSessao(),
                            Timestamp.valueOf(dataPagamento), Timestamp.valueOf(LocalDateTime.now()), false, true,
                            rb_mensalidadeNormal.isSelected() ? "Mensalidade Normal" : "Mensalidade Familiar", valParc));
                else
                {

                    String combo = "";
                    switch ((int) parcelas)
                    {
                        case 3:
                            combo = "Combo 3 meses / Mes";
                            break;

                        case 6:
                            combo = "Combo 6 meses / Mes";
                            break;

                        case 12:
                            combo = "Combo Anual / Mes";
                            break;

                    }

                    LocalDateTime ldtaux = dataPagamento;
                    for (int i = 0; i < parcelas; i++, ldtaux = ldtaux.plusMonths(1))
                        all.add(new Lancamento(cliente, rosolen.Rosolen.getInstance().getSessao(),
                                Timestamp.valueOf(ldtaux), Timestamp.valueOf(LocalDateTime.now()), false, true,
                                combo + " " + (i + 1) + " / " + (rb_mensalidadeNormal.isSelected() ? "Mensalidade Normal" : "Mensalidade Familiar"), valParc));
                }
            }

            if (all.size() > 0)
            {
                dataPagamento = dataPagamento.plusMonths((int) parcelas - 1);
                CtrLancamento ctrlan = new CtrLancamento();
                for (Lancamento l : all)
                    ctrlan.salvar(l);

                String sql = "update pessoa set sit_cod=# where pes_cod=" + cliente.getCod();

                if (dataPagamento.getYear() > LocalDate.now().getYear())
                    sql = sql.replace("#", "1");
                else if (dataPagamento.getYear() == LocalDate.now().getYear()) // mesmo ano
                {
                    if (dataPagamento.getMonthValue() >= LocalDate.now().getMonthValue()) // mes atual ou adiantado - normal
                        sql = sql.replace("#", "1");
                    else if (dataPagamento.plusMonths(1).getMonthValue() == LocalDate.now().getMonthValue()
                            || dataPagamento.plusMonths(2).getMonthValue() == LocalDate.now().getMonthValue()) // ate 2 meses atrasado - pendente
                        sql = sql.replace("#", "2");
                    else if (dataPagamento.plusMonths(2).getMonthValue() < LocalDate.now().getMonthValue()) // mais de 2 meses atrasado - inativo
                        sql = sql.replace("#", "3");
                } else if (dataPagamento.getYear() + 1 == LocalDate.now().getYear()) //ano anterior                
                    if (dataPagamento.plusMonths(1).getMonthValue() == LocalDate.now().getMonthValue()
                            || dataPagamento.plusMonths(2).getMonthValue() == LocalDate.now().getMonthValue()) // ate 2 meses atrasado - pendente
                        sql = sql.replace("#", "2");
                    else if (dataPagamento.plusMonths(2).getMonthValue() < LocalDate.now().getMonthValue()) // mais de 2 meses atrasado - inativo
                        sql = sql.replace("#", "3");

                if (Conexao.get().manipular(sql))
                {
                    cliente = new CtrPessoa().get(cliente);
                    if (cliente.getSituacao().getCod() == 1)
                    {
                        all.clear();
                        all = ctrlan.getAll("pes_cod = " + cliente.getCod() + " and mensalidade = true", "order by datamens desc");
                        if (all.size() > 11)
                        {
                            valido = true;
                            int i;
                            for (i = 0; i < all.size() - 1 && valido; i++)
                            {
                                int aux = all.get(i).getDataMens().toLocalDateTime().getMonthValue();
                                if (aux == 1)
                                {
                                    if (all.get(i + 1).getDataMens().toLocalDateTime().getMonthValue() != 12)
                                        valido = false;
                                } else if (aux - 1 != all.get(i + 1).getDataMens().toLocalDateTime().getMonthValue())
                                    valido = false;
                            }

                            if (valido || i >= 11)
                            {
                                sql = "update pessoa set sit_cod=4, mesvip = " + (i + 1) + " where pes_cod=" + cliente.getCod();
                                Conexao.get().manipular(sql);
                            }
                        }
                    }
                }
            }
        }
        limpaTela();
    }
}
