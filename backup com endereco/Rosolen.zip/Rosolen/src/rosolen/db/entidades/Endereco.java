package rosolen.db.entidades;

public class Endereco
{

    private String cep;
    private Cidade cidade;
    private String tipolog;
    private String logradouro;
    private String endcompleto;
    private String bairro;

    public Endereco()
    {
        this("", new Cidade(), "", "");
    }

    public Endereco(String cep, Cidade cidade, String endcompleto, String bairro)
    {
        this.cep = cep;
        this.cidade = cidade;
        this.setEndcompleto(endcompleto);
        this.bairro = bairro;
    }

    public Cidade getCidade()
    {
        return cidade;
    }

    public void setCidade(Cidade cidade)
    {
        this.cidade = cidade;
    }

    public String getTipolog()
    {
        return tipolog;
    }

    public String getLogradouro()
    {
        return logradouro;
    }

    public String getBairro()
    {
        return bairro;
    }

    public void setBairro(String bairro)
    {
        this.bairro = bairro;
    }

    public String getEndcompleto()
    {
        return endcompleto;
    }

    public String getCep()
    {
        return cep;
    }

    public void setCep(String cep)
    {
        this.cep = cep;
    }

    public void setTipolog(String tipolog)
    {
        this.tipolog = tipolog;
    }

    public void setLogradouro(String logradouro)
    {
        this.logradouro = logradouro;
    }

    public void setEndcompleto(String endcompleto)
    {
        this.endcompleto = endcompleto;
        this.tipolog = "";
        this.logradouro = "";
        if (!endcompleto.trim().isEmpty())
        {
            String endcompletotemp = endcompleto;
            this.tipolog = endcompletotemp.substring(0, endcompletotemp.indexOf(' '));
            endcompletotemp = endcompletotemp.substring(endcompletotemp.indexOf(' ') + 1);

            String logtemp = endcompletotemp.substring(0, 3);

            if (logtemp.equals("das") || logtemp.equals("dos"))
                endcompletotemp = endcompletotemp.substring(4);

            this.logradouro = endcompletotemp;
        }
    }

    public void setEndcompleto(String tipoLogradouro, String logradouro)
    {
        this.endcompleto = tipoLogradouro + " " + logradouro;
    }

    @Override
    public String toString()
    {
        return this.cep;
    }
}
