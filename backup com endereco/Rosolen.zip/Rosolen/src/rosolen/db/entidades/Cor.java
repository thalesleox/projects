/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

/**
 *
 * @author thale
 */
public class Cor
{

    private int cod;
    private String Descricao;
    private boolean opaco;
    private boolean fluorescente;
    private boolean gliterizado;
    private boolean metalico;

    public Cor(int cod, String descricao, boolean opaco, boolean fluorescente, boolean gliterizado, boolean metalico)
    {
        this.cod = cod;
        this.Descricao = descricao;
        this.opaco = opaco;
        this.fluorescente = fluorescente;
        this.gliterizado = gliterizado;
        this.metalico = metalico;
    }

    public Cor(String descricao, boolean opaco, boolean fluorescente, boolean gliterizado, boolean metalico)
    {
        this(0, descricao, opaco, fluorescente, gliterizado, metalico);
    }

    public Cor()
    {
        this(0, "", false, false, false, false);
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public String getDescricao()
    {
        return Descricao;
    }

    public void setDescricao(String Descricao)
    {
        this.Descricao = Descricao;
    }

    public boolean isOpaco()
    {
        return opaco;
    }

    public void setOpaco(boolean opaco)
    {
        this.opaco = opaco;
    }

    public boolean isFluorescente()
    {
        return fluorescente;
    }

    public void setFluorescente(boolean fluorescente)
    {
        this.fluorescente = fluorescente;
    }

    public boolean isGliterizado()
    {
        return gliterizado;
    }

    public void setGliterizado(boolean gliterizado)
    {
        this.gliterizado = gliterizado;
    }

    public boolean isMetalico()
    {
        return metalico;
    }

    public void setMetalico(boolean metalico)
    {
        this.metalico = metalico;
    }

    @Override
    public String toString()
    {
        return this.Descricao + (opaco ? " Opaco" : "") + (fluorescente ? " Fluorescente" : "") + (gliterizado ? " Gliterizado" : "") + (metalico ? " Metalico" : "");
    }

}
