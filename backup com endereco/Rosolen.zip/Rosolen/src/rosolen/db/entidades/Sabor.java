/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

/**
 *
 * @author thale
 */
public class Sabor
{

    private int cod;
    private String descricao;
    private boolean integral;
    private boolean artificial;

    public Sabor(int cod, String descricao, boolean integral, boolean artificial)
    {
        this.cod = cod;
        this.descricao = descricao;
        this.integral = integral;
        this.artificial = artificial;
    }

    public Sabor(String descricao, boolean integral, boolean artificial)
    {
        this(0, descricao, false, false);
    }

    public Sabor()
    {
        this(0, "", false, false);
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }

    public boolean isIntegral()
    {
        return integral;
    }

    public void setIntegral(boolean integral)
    {
        this.integral = integral;
    }

    public boolean isArtificial()
    {
        return artificial;
    }

    public void setArtificial(boolean artificial)
    {
        this.artificial = artificial;
    }

    @Override
    public String toString()
    {
        return this.descricao + (this.integral ? " Integral" : "") + (this.artificial ? " Artificial" : "");
    }

}
