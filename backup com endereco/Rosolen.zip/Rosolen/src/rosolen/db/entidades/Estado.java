/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

/**
 *
 * @author Aluno
 */
public class Estado
{

    private int cod;
    private String sigla;

    public Estado()
    {
        this(0, "");
    }

    public Estado(String nome, String sigla)
    {
        this(0, sigla);
    }

    public Estado(int cod, String sigla)
    {
        this.cod = cod;
        this.sigla = sigla;
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public String getSigla()
    {
        return sigla;
    }

    public void setSigla(String sigla)
    {
        this.sigla = sigla;
    }

    @Override
    public String toString()
    {
        return "Estado{" + "cod=" + cod + ", sigla=" + sigla + '}';
    }
}
