/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;

/**
 *
 * @author thale
 */
public class Venda
{

    private int cod;
    private Pessoa cliente;
    private float total;
    private float desconto;
    private float creditoUtilizado;
    private float creditoAcrescentado;
    private ArrayList<Item> items;
    private Timestamp data;

    private class Item
    {

        private Servico servico;
        private Produto produto;
        private int quantidade;
        private float total;

        public Item(Servico servico, Produto produto, int quantidade, float total)
        {
            this.servico = servico;
            this.produto = produto;
            this.quantidade = quantidade;
            this.total = total;
        }

        public Item()
        {
            this(new Servico(), new Produto(), 0, 0f);
        }

        public Servico getServico()
        {
            return servico;
        }

        public void setServico(Servico servico)
        {
            this.servico = servico;
        }

        public Produto getProduto()
        {
            return produto;
        }

        public void setProduto(Produto produto)
        {
            this.produto = produto;
        }

        public int getQuantidade()
        {
            return quantidade;
        }

        public void setQuantidade(int quantidade)
        {
            this.quantidade = quantidade;
        }

        public float getTotal()
        {
            return total;
        }

        public void setTotal(float total)
        {
            this.total = total;
        }

    }

    public Venda(int cod, Pessoa cliente, float total, float desconto, float creditoUtilizado, float creditoAcrescentado, ArrayList<Item> items, Timestamp data)
    {
        this.cod = cod;
        this.cliente = cliente;
        this.total = total;
        this.desconto = desconto;
        this.creditoUtilizado = creditoUtilizado;
        this.creditoAcrescentado = creditoAcrescentado;
        this.items = items;
        this.data = data;
    }

    public Venda(Pessoa cliente, float total, float desconto, float creditoUtilizado, float creditoAcrescentado, ArrayList<Item> items, Timestamp data)
    {
        this(0, cliente, total, desconto, creditoUtilizado, creditoAcrescentado, items, data);
    }

    public Venda()
    {
        this(0, new Pessoa(), 0f, 0f, 0f, 0f, new ArrayList<Item>(), Timestamp.valueOf(LocalDate.now().atStartOfDay()));
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public Pessoa getCliente()
    {
        return cliente;
    }

    public void setCliente(Pessoa cliente)
    {
        this.cliente = cliente;
    }

    public float getTotal()
    {
        return total;
    }

    public void setTotal(float total)
    {
        this.total = total;
    }

    public float getDesconto()
    {
        return desconto;
    }

    public void setDesconto(float desconto)
    {
        this.desconto = desconto;
    }

    public float getCreditoUtilizado()
    {
        return creditoUtilizado;
    }

    public void setCreditoUtilizado(float creditoUtilizado)
    {
        this.creditoUtilizado = creditoUtilizado;
    }

    public float getCreditoAcrescentado()
    {
        return creditoAcrescentado;
    }

    public void setCreditoAcrescentado(float creditoAcrescentado)
    {
        this.creditoAcrescentado = creditoAcrescentado;
    }

    public ArrayList<Item> getItems()
    {
        return items;
    }

    public void setItems(ArrayList<Item> items)
    {
        this.items = items;
    }

    public Timestamp getData()
    {
        return data;
    }

    public void setData(Timestamp data)
    {
        this.data = data;
    }

}
