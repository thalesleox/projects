/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

import java.awt.image.BufferedImage;

/**
 *
 * @author thale
 */
public class Produto
{

    private int cod;
    private String descricao;
    private Marca marca;
    private float valor;
    private String quantmedida;
    private UnidadeMedida unidademedida;
    private int estoque;
    private Sabor sabor;
    private Cor cor;
    private BufferedImage img;

    public Produto(int cod, String descricao, Marca marca, float valor, String quantmedida, UnidadeMedida unidademedida, int estoque, Sabor sabor, Cor cor, BufferedImage img)
    {
        this.cod = cod;
        this.descricao = descricao;
        this.marca = marca;
        this.valor = valor;
        this.quantmedida = quantmedida;
        this.unidademedida = unidademedida;
        this.estoque = estoque;
        this.sabor = sabor;
        this.cor = cor;
        this.img = img;
    }

    public Produto(String descricao, Marca marca, float valor, String quantmedida, UnidadeMedida unidademedida, int estoque, Sabor sabor, Cor cor, BufferedImage img)
    {
        this(0, descricao, marca, valor, quantmedida, unidademedida, estoque, sabor, cor, img);
    }

    public Produto()
    {
        this(0, "", new Marca(), 0f, "", new UnidadeMedida(), 0, new Sabor(), new Cor(), null);
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public String getDescricao()
    {
        return descricao;
    }

    public void setDescricao(String descricao)
    {
        this.descricao = descricao;
    }

    public Marca getMarca()
    {
        return marca;
    }

    public void setMarca(Marca marca)
    {
        this.marca = marca;
    }

    public float getValor()
    {
        return valor;
    }

    public void setValor(float valor)
    {
        this.valor = valor;
    }

    public String getQuantmedida()
    {
        return quantmedida;
    }

    public void setQuantmedida(String quantmedida)
    {
        this.quantmedida = quantmedida;
    }

    public UnidadeMedida getUnidademedida()
    {
        return unidademedida;
    }

    public void setUnidademedida(UnidadeMedida unidademedida)
    {
        this.unidademedida = unidademedida;
    }

    public int getEstoque()
    {
        return estoque;
    }

    public void setEstoque(int estoque)
    {
        this.estoque = estoque;
    }

    public Sabor getSabor()
    {
        return sabor;
    }

    public void setSabor(Sabor sabor)
    {
        this.sabor = sabor;
    }

    public Cor getCor()
    {
        return cor;
    }

    public void setCor(Cor cor)
    {
        this.cor = cor;
    }

    public BufferedImage getImg()
    {
        return img;
    }

    public void setImg(BufferedImage img)
    {
        this.img = img;
    }

    @Override
    public String toString()
    {
        return descricao + (sabor != null ? " " + sabor.toString() : "") + (cor != null ? " " + cor.toString() : "") + (marca != null ? " " + marca.getSigla() : "");
    }

}
