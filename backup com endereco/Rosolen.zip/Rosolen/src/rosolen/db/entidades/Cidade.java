/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.entidades;

/**
 *
 * @author Aluno
 */
public class Cidade
{

    private int cod;
    private String nome;
    private Estado estado;

    public Cidade()
    {
        this(0, "", new Estado());
    }

    public Cidade(String nome, Estado estado)
    {
        this(0, nome, estado);
    }

    public Cidade(int cod, String nome, Estado estado)
    {
        this.cod = cod;
        this.nome = nome;
        this.estado = estado;
    }

    public int getCod()
    {
        return cod;
    }

    public void setCod(int cod)
    {
        this.cod = cod;
    }

    public String getNome()
    {
        return nome;
    }

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public Estado getEstado()
    {
        return estado;
    }

    public void setEstado(Estado estado)
    {
        this.estado = estado;
    }

    @Override
    public String toString()
    {
        return "Cidade{" + "cod=" + cod + ", nome=" + nome + ", estado=" + estado.toString() + '}';
    }

}
