/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.UnidadeMedida;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrUnidadeMedida
{

    public boolean salvar(UnidadeMedida unidademedida)
    {
        String sql = "insert into unidademedida(descricao,sigla) "
                + "values('$1','$2')";
        sql = sql.replace("$1", unidademedida.getDescricao());
        sql = sql.replace("$2", "" + unidademedida.getSigla());
        return Conexao.get().manipular(sql);
    }

    public UnidadeMedida get(int cod)
    {
        String sql = "select * from unidademedida where unm_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        UnidadeMedida unidademedida = null;
        try
        {
            if (rs.next())
                unidademedida = new UnidadeMedida(cod, rs.getString("descricao"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrUnidadeMedida.class.getName()).log(Level.SEVERE, null, ex);
        }
        return unidademedida;
    }

    public UnidadeMedida get(String descricao)
    {
        String sql = "select * from unidademedida where descricao ilike '%$1%'";
        sql = sql.replace("$1", descricao);
        ResultSet rs = Conexao.get().consultar(sql);
        UnidadeMedida unidademedida = null;
        try
        {
            if (rs.next())
                unidademedida = new UnidadeMedida(rs.getInt("unm_cod"), rs.getString("descricao"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrUnidadeMedida.class.getName()).log(Level.SEVERE, null, ex);
        }

        return unidademedida;
    }

    public ArrayList<UnidadeMedida> getAll(String filtro, String filtro2)
    {
        String sql = "select * from unidademedida";
        if (!filtro.isEmpty())
            sql += " where " + filtro;
        if (!filtro2.isEmpty())
            sql += " " + filtro2;

        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<UnidadeMedida> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new UnidadeMedida(rs.getInt("unm_cod"), rs.getString("descricao"), rs.getString("sigla")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrUnidadeMedida.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
}
