/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.Cidade;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrCidade
{

    public boolean salvar(Cidade cidade)
    {
        String sql = "insert into cidade(nome,est_cod) values('$1',$2)";
        sql = sql.replace("$1", cidade.getNome());
        sql = sql.replace("$2", "" + cidade.getEstado().getCod());
        return Conexao.get().manipular(sql);
    }

    public Cidade get(int cod)
    {
        String sql = "select * from cidade where cid_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Cidade cid = null;
        try
        {
            if (rs.next())
                cid = new Cidade(rs.getInt("cid_cod"), rs.getString("nome"), new CtrEstado().get(rs.getInt("est_cod")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
            cid = null;
        }
        return cid;
    }

    public Cidade get(String nome)
    {
        String sql = "select * from cidade where nome='$1'";
        sql = sql.replace("$1", nome);
        ResultSet rs = Conexao.get().consultar(sql);
        Cidade cid = null;
        try
        {
            if (rs.next())
                cid = new Cidade(rs.getInt("cid_cod"), rs.getString("nome"), new CtrEstado().get(rs.getInt("est_cod")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return cid;
        }
    }

    public ArrayList<Cidade> getAll(String nome)
    {
        String sql = "select * from cidade where nome like '%$1%'";
        sql = sql.replace("$1", nome);
        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Cidade> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Cidade(rs.getInt("cid_cod"), rs.getString("nome"), new CtrEstado().get(rs.getInt("est_cod"))));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return al;
        }
    }
}
