/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.Estado;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrEstado
{

    public boolean salvar(Estado estado)
    {
        String sql = "insert into estado(sigla) values('$1')";
        sql = sql.replace("$1", estado.getSigla());

        return Conexao.get().manipular(sql);
    }

    public Estado get(int cod)
    {
        String sql = "select * from estado where est_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Estado est = null;
        try
        {
            if (rs.next())
                est = new Estado(rs.getInt("est_cod"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return est;
        }
    }

    public Estado get(String sigla)
    {
        String sql = "select * from estado where sigla='$1'";
        sql = sql.replace("$1", sigla);
        ResultSet rs = Conexao.get().consultar(sql);
        Estado est = null;
        try
        {
            if (rs.next())
                est = new Estado(rs.getInt("est_cod"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return est;
        }
    }

    public ArrayList<Estado> getAll(String sigla)
    {
        String sql = "select * from estado where sigla like '%$1%'";
        sql = sql.replace("$1", sigla);
        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Estado> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Estado(rs.getInt("est_cod"), rs.getString("sigla")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCidade.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return al;
        }
    }
}
