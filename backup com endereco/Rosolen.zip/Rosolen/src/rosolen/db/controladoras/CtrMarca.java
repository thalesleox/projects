/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.Marca;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrMarca
{

    public boolean salvar(Marca marca)
    {
        String sql = "insert into marca(descricao,sigla) "
                + "values('$1','$2')";
        sql = sql.replace("$1", marca.getDescricao());
        sql = sql.replace("$2", marca.getSigla());
        return Conexao.get().manipular(sql);
    }

    public Marca get(int cod)
    {
        String sql = "select * from marca where mar_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Marca marca = null;
        try
        {
            if (rs.next())
                marca = new Marca(cod, rs.getString("descricao"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
        return marca;
    }

    public Marca get(String descricao)
    {
        String sql = "select * from marca where descricao ilike '%$1%'";
        sql = sql.replace("$1", descricao);
        ResultSet rs = Conexao.get().consultar(sql);
        Marca marca = null;
        try
        {
            if (rs.next())
                marca = new Marca(rs.getInt("mar_cod"), rs.getString("descricao"), rs.getString("sigla"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrMarca.class.getName()).log(Level.SEVERE, null, ex);
        }

        return marca;
    }

    public ArrayList<Marca> getAll(String filtro, String filtro2)
    {
        String sql = "select * from marca";
        if (!filtro.isEmpty())
            sql += " where " + filtro;
        if (!filtro2.isEmpty())
            sql += " " + filtro2;

        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Marca> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Marca(rs.getInt("mar_cod"), rs.getString("descricao"), rs.getString("sigla")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrMarca.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
}
