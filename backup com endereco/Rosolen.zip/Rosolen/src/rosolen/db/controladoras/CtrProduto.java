/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import rosolen.db.entidades.Produto;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrProduto
{

    public boolean salvar(Produto produto)
    {
        boolean status = false;
        try
        {
            Conexao.get().getConnect().setAutoCommit(false);
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrPessoa.class.getName()).log(Level.SEVERE, null, ex);
        }

        String sql = "insert into produto(descricao,mar_cod,valor,quantmedida,unm_cod,estoque,sab_cod,cor_cod) "
                + "values('$1',$2,$3,'$4',$5,$6,$7,$8)";
        sql = sql.replace("$1", produto.getDescricao());
        sql = sql.replace("$2", "" + produto.getMarca().getCod());
        sql = sql.replace("$3", "" + produto.getValor());
        sql = sql.replace("$4", produto.getQuantmedida());
        sql = sql.replace("$5", "" + produto.getUnidademedida().getCod());
        sql = sql.replace("$6", "" + produto.getEstoque());
        sql = sql.replace("$7", "" + produto.getSabor().getCod());
        sql = sql.replace("$8", "" + produto.getCor().getCod());

        if (status = Conexao.get().manipular(sql))
            status = SalvarImagem(produto);

        if (!status)
            try
            {
                Conexao.get().getConnect().rollback();
            } catch (SQLException ex)
            {
                Logger.getLogger(CtrPessoa.class.getName()).log(Level.SEVERE, null, ex);
            }
        try
        {
            Conexao.get().getConnect().setAutoCommit(true);
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrPessoa.class.getName()).log(Level.SEVERE, null, ex);
        }

        return status;
    }

    public Produto get(int cod)
    {
        String sql = "select * from produto where pro_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Produto pro = null;
        try
        {
            if (rs.next())
                pro = new Produto(cod, rs.getString("descricao"), new CtrMarca().get(rs.getInt("mar_cod")), rs.getLong("valor"), rs.getString("quantmedida"),
                        new CtrUnidadeMedida().get(rs.getInt("unm_cod")), rs.getInt("estoque"), new CtrSabor().get(rs.getInt("sab_cod")),
                        new CtrCor().get(rs.getInt("cor_cod")), obterImagem(rs.getBytes("foto")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pro;
    }

    public Produto get(String descricao)
    {
        String sql = "select * from produto where descricao ilike '%$1%'";
        sql = sql.replace("$1", descricao);
        ResultSet rs = Conexao.get().consultar(sql);
        Produto pro = null;
        try
        {
            if (rs.next())
                pro = new Produto(rs.getInt("pro_cod"), rs.getString("descricao"), new CtrMarca().get(rs.getInt("mar_cod")), rs.getLong("valor"), rs.getString("quantmedida"),
                        new CtrUnidadeMedida().get(rs.getInt("unm_cod")), rs.getInt("estoque"), new CtrSabor().get(rs.getInt("sab_cod")),
                        new CtrCor().get(rs.getInt("cor_cod")), obterImagem(rs.getBytes("foto")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return pro;
    }

    public ArrayList<Produto> getAll(String filtro, String filtro2)
    {
        String sql = "select * from produto";
        if (!filtro.isEmpty())
            sql += " where " + filtro;
        if (!filtro2.isEmpty())
            sql += " " + filtro2;

        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Produto> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Produto(rs.getInt("pro_cod"), rs.getString("descricao"), new CtrMarca().get(rs.getInt("mar_cod")), rs.getLong("valor"), rs.getString("quantmedida"),
                        new CtrUnidadeMedida().get(rs.getInt("unm_cod")), rs.getInt("estoque"), new CtrSabor().get(rs.getInt("sab_cod")),
                        new CtrCor().get(rs.getInt("cor_cod")), obterImagem(rs.getBytes("foto"))));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }

    public boolean SalvarImagem(Produto p)
    {
        try
        {
            PreparedStatement st = Conexao.get().getConnect().prepareStatement(
                    "update produto set foto=? where pro_cod=?");
            if (p.getImg() == null)
            {
                st.setNull(1, java.sql.Types.NULL);
                st.setInt(2, p.getCod());
            } else
            {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ImageIO.write(p.getImg(), "jpg", baos);
                InputStream is = new ByteArrayInputStream(baos.toByteArray());
                st.setBinaryStream(1, is, baos.toByteArray().length);
                st.setInt(2, p.getCod());
            }
            st.executeUpdate();
            return true;

        } catch (Exception e)
        {
            System.out.println(e);
        }
        return false;
    }

    public BufferedImage obterImagem(byte bytes[])
    {
        BufferedImage bi = null;
        try
        {
            if (bytes != null)
                bi = ImageIO.read(new ByteArrayInputStream(bytes));
        } catch (IOException ex)
        {
            System.out.println("Erro obter imagem: " + ex.getMessage());
        }
        return bi;
    }
}
