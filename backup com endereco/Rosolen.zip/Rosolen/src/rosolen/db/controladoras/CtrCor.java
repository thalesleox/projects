/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.Cor;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrCor
{

    public boolean salvar(Cor cor)
    {
        String sql = "insert into cor(descricao,opaco,fluorescente,gliterizado,metalico) "
                + "values('$1',$2,$3,$4,$5)";
        sql = sql.replace("$1", cor.getDescricao());
        sql = sql.replace("$2", "" + cor.isOpaco());
        sql = sql.replace("$3", "" + cor.isFluorescente());
        sql = sql.replace("$4", "" + cor.isGliterizado());
        sql = sql.replace("$5", "" + cor.isMetalico());
        return Conexao.get().manipular(sql);
    }

    public Cor get(int cod)
    {
        String sql = "select * from cor where cor_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Cor cor = null;
        try
        {
            if (rs.next())
                cor = new Cor(cod, rs.getString("descricao"), rs.getBoolean("opaco"), rs.getBoolean("fluorescente"), rs.getBoolean("gliterizado"), rs.getBoolean("metalico"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return cor;
    }

    public Cor get(String descricao)
    {
        String sql = "select * from cor where descricao ilike '%$1%'";
        sql = sql.replace("$1", descricao);
        ResultSet rs = Conexao.get().consultar(sql);
        Cor cor = null;
        try
        {
            if (rs.next())
                cor = new Cor(rs.getInt("cor_cod"), rs.getString("descricao"), rs.getBoolean("opaco"), rs.getBoolean("fluorescente"), rs.getBoolean("gliterizado"), rs.getBoolean("metalico"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return cor;
    }

    public ArrayList<Cor> getAll(String filtro, String filtro2)
    {
        String sql = "select * from cor";
        if (!filtro.isEmpty())
            sql += " where " + filtro;
        if (!filtro2.isEmpty())
            sql += " " + filtro2;

        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Cor> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Cor(rs.getInt("cor_cod"), rs.getString("descricao"), rs.getBoolean("opaco"), rs.getBoolean("fluorescente"), rs.getBoolean("gliterizado"), rs.getBoolean("metalico")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrCor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
}
