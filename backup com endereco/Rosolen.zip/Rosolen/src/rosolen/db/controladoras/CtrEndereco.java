/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONObject;
import rosolen.db.entidades.Cidade;
import rosolen.db.entidades.Endereco;
import rosolen.db.entidades.Estado;
import rosolen.db.util.AcessoCEP;
import rosolen.db.util.Conexao;

/**
 *
 * @author Aluno
 */
public class CtrEndereco
{

    /*
    "status":1,
    "code":"06233-030",
    "state":"SP",
    "city":"Osasco",
    "district":"Piratininga",
    "address":"Rua Paula Rodrigues"
     */
    private boolean _salvar(Endereco endereco)
    {
        String sql = "insert into endereco(cep,cid_cod,endcompleto,bairro) values('$1',$2,'$3','$4')";
        sql = sql.replace("$1", endereco.getCep());
        sql = sql.replace("$2", "" + endereco.getCidade().getCod());
        sql = sql.replace("$3", endereco.getEndcompleto());
        sql = sql.replace("$4", endereco.getBairro());

        return Conexao.get().manipular(sql);
    }

    public boolean salvar(Endereco end)
    {

        Cidade cid = new CtrCidade().get(end.getCidade().getNome());
        if (cid == null)
        {
            Estado est = new CtrEstado().get(end.getCidade().getEstado().getSigla());
            if (est == null)
            {
                est = new Estado();
                est.setSigla(end.getCidade().getEstado().getSigla());
                CtrEstado ctrest = new CtrEstado();
                ctrest.salvar(est);
                est = ctrest.get(end.getCidade().getEstado().getSigla());
            }
            cid = new Cidade();
            cid.setNome(end.getCidade().getNome());
            cid.setEstado(est);
            CtrCidade ctrcid = new CtrCidade();
            ctrcid.salvar(cid);
            cid = ctrcid.get(end.getCidade().getNome());
        }

        end.setEndcompleto(end.getTipolog(), end.getLogradouro());
        end.setCidade(cid);
        CtrEndereco ctrend = new CtrEndereco();
        return ctrend._salvar(end);
    }

    public Endereco getCepWS(String cep)
    {
        Endereco end = get(cep);

        if (end == null)
        {
            String str = new AcessoCEP().consultaCep(cep, "json");
            JSONObject my_obj = new JSONObject(str);

            if (my_obj.getInt("status") == 1)
                try
                {
                    end = new Endereco();
                    end.setCep(cep);

                    Cidade cid = new CtrCidade().get(my_obj.getString("city"));
                    if (cid == null)
                    {
                        Estado est = new CtrEstado().get(my_obj.getString("state"));
                        if (est == null)
                        {
                            est = new Estado();
                            est.setSigla(my_obj.getString("state"));
                            CtrEstado ctrest = new CtrEstado();
                            ctrest.salvar(est);
                            est = ctrest.get(my_obj.getString("state"));
                        }
                        cid = new Cidade();
                        cid.setNome(my_obj.getString("city"));
                        cid.setEstado(est);
                        CtrCidade ctrcid = new CtrCidade();
                        ctrcid.salvar(cid);
                        cid = ctrcid.get(my_obj.getString("city"));
                    }

                    end.setCidade(cid);
                    end.setEndcompleto(my_obj.getString("address"));
                    end.setBairro(my_obj.getString("district"));
                    CtrEndereco ctrend = new CtrEndereco();
                    ctrend._salvar(end);
                    end = ctrend.get(cep);
                } catch (Exception ex)
                {
                    end = null;
                }
            else
                end = null;
        }
        return end;
    }

    public Endereco get(String cep)
    {
        Endereco end = null;
        String sql = "select * from endereco where cep='$1'";
        sql = sql.replace("$1", cep);
        ResultSet rs = Conexao.get().consultar(sql);
        try
        {
            if (rs.next())
                end = new Endereco(cep, new CtrCidade().get(rs.getInt("cid_cod")), rs.getString("endcompleto"), rs.getString("bairro"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrEndereco.class.getName()).log(Level.SEVERE, null, ex);
        } finally
        {
            return end;
        }
    }
}
