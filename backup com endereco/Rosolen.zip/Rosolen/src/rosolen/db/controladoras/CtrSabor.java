/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rosolen.db.controladoras;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import rosolen.db.entidades.Sabor;
import rosolen.db.util.Conexao;

/**
 *
 * @author thale
 */
public class CtrSabor
{

    public boolean salvar(Sabor sabor)
    {
        String sql = "insert into sabor(descricao,integral,artificial) "
                + "values('$1',$2,$3)";
        sql = sql.replace("$1", sabor.getDescricao());
        sql = sql.replace("$2", "" + sabor.isIntegral());
        sql = sql.replace("$3", "" + sabor.isArtificial());
        return Conexao.get().manipular(sql);
    }

    public Sabor get(int cod)
    {
        String sql = "select * from sabor where sab_cod=" + cod;
        ResultSet rs = Conexao.get().consultar(sql);
        Sabor sabor = null;
        try
        {
            if (rs.next())
                sabor = new Sabor(cod, rs.getString("descricao"), rs.getBoolean("integral"), rs.getBoolean("artificial"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrSabor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return sabor;
    }

    public Sabor get(String descricao)
    {
        String sql = "select * from sabor where descricao ilike '%$1%'";
        sql = sql.replace("$1", descricao);
        ResultSet rs = Conexao.get().consultar(sql);
        Sabor sabor = null;
        try
        {
            if (rs.next())
                sabor = new Sabor(rs.getInt("sab_cod"), rs.getString("descricao"), rs.getBoolean("integral"), rs.getBoolean("artificial"));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrSabor.class.getName()).log(Level.SEVERE, null, ex);
        }

        return sabor;
    }

    public ArrayList<Sabor> getAll(String filtro, String filtro2)
    {
        String sql = "select * from sabor";
        if (!filtro.isEmpty())
            sql += " where " + filtro;
        if (!filtro2.isEmpty())
            sql += " " + filtro2;

        ResultSet rs = Conexao.get().consultar(sql);
        ArrayList<Sabor> al = new ArrayList();
        try
        {
            while (rs.next())
                al.add(new Sabor(rs.getInt("sab_cod"), rs.getString("descricao"), rs.getBoolean("integral"), rs.getBoolean("artificial")));
        } catch (SQLException ex)
        {
            Logger.getLogger(CtrSabor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return al;
    }
}
